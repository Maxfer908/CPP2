#include "animal.h"
Animal::Animal()
    {
        name = "Bilbo";
        health = 50+ (rand() % 1000);
        happiness = 50 + (rand() % 1000);
        food = 50 + (rand() % 1000);
    }
    Animal::~Animal() {}
    void Animal::feed()
    {
        food += 150;
    }
    void Animal::play() {
        happiness += 150;
    }

    void Animal::wash() {
        health += 150;
    }
    bool Animal::isAlive(){
        if ((food <= 0) || (happiness <= 0) || (health <= 0))
            return false;
        return true;
    }
