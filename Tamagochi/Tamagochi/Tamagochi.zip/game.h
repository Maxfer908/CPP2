#ifndef GAME_H
#define GAME_H


class game
{
public:
    game();
private:
    int amount;
    Animal animals[256];
};

#endif // GAME_H
